module.exports = {
  siteUrl: "https://www.laser-31.ru/", // Замените на ваш домен
  generateRobotsTxt: true, // Создаёт robots.txt
};
